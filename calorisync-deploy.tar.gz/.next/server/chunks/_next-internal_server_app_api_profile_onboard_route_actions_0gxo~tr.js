module.exports=[1913,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_profile_onboard_route_actions_0gxo~tr.js.map