module.exports=[2528,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28auth%29_auth_verify_page_actions_08xcpgd.js.map