module.exports=[25259,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28console%29_console_page_actions_0iub1.u.js.map