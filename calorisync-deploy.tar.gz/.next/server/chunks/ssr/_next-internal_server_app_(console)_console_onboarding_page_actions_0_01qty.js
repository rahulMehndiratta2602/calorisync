module.exports=[70783,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28console%29_console_onboarding_page_actions_0_01qty.js.map