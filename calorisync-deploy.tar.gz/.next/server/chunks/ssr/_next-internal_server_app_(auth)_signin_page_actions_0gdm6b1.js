module.exports=[23535,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28auth%29_signin_page_actions_0gdm6b1.js.map