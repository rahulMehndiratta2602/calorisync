var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/signout/route.js")
R.c("server/chunks/[root-of-the-server]__0sbkx9d._.js")
R.c("server/chunks/_0ob_fhd._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/node_modules_drizzle-orm_sql_expressions_conditions_0la-vjt.js")
R.c("server/chunks/_next-internal_server_app_api_auth_signout_route_actions_00gx.76.js")
R.m(67567)
module.exports=R.m(67567).exports
