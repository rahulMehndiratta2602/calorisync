var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/newsletter/route.js")
R.c("server/chunks/[root-of-the-server]__10wdcfv._.js")
R.c("server/chunks/node_modules_zod_v3_external_0_2gmko.js")
R.c("server/chunks/node_modules_drizzle-orm_sql_expressions_conditions_0la-vjt.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_newsletter_route_actions_0i9gk0-.js")
R.m(87497)
module.exports=R.m(87497).exports
