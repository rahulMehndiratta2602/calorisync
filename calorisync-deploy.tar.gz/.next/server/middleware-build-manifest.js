globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/jCOuHP-R6h-ww3iwfd8ed/_buildManifest.js",
    "static/jCOuHP-R6h-ww3iwfd8ed/_ssgManifest.js",
    "static/jCOuHP-R6h-ww3iwfd8ed/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ze4gu236oq96.js",
    "static/chunks/0_mai1dyk.4_9.js",
    "static/chunks/10ps847iauksh.js",
    "static/chunks/0.oho4lbh1wrz.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/turbopack-0qmpmeumzeuaf.js"
  ]
};
